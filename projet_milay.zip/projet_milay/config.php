<?php
// config.php — configuration de la connexion à la base de données

$host = 'localhost';       // ou votre serveur MySQL
$db = 'gestion_societe';  // nom de la base de données
$user = 'root';            // utilisateur MySQL
$pass = '';                // mot de passe MySQL
$charset = 'utf8mb4';

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_errno) {
    die('Échec de la connexion à la base de données : ' . $mysqli->connect_error);
}
$mysqli->set_charset($charset);
?>