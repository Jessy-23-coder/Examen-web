<?php
session_start();
require_once __DIR__ . '/config.php';

if (empty($_SESSION['entreprise_id'])) {
    header('Location: login.php');
    exit;
}

$entreprise_id = $_SESSION['entreprise_id'];
$errors = [];
$success = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dirigeant = trim($_POST['org_dirigeant'] ?? '');
    $duree_vie = intval($_POST['duree_vie'] ?? 0);
    $benefice = floatval($_POST['repartition_benefice'] ?? 0);
    $perte = floatval($_POST['repartition_perte'] ?? 0);

    if ($dirigeant === '' || $duree_vie <= 0) $errors[] = 'Dirigeant et durée de vie requis.';

    if (empty($errors)) {
        $stmt = $mysqli->prepare('SELECT id FROM organisation_societe WHERE entreprise_id=? LIMIT 1');
        $stmt->bind_param('i', $entreprise_id);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->close();
            $stmt = $mysqli->prepare('UPDATE organisation_societe SET org_dirigeant=?, duree_vie_annees=?, repartition_benefice=?, repartition_perte=? WHERE entreprise_id=?');
            $stmt->bind_param('siddi', $dirigeant, $duree_vie, $benefice, $perte, $entreprise_id);
            if ($stmt->execute()) $success[] = 'Organisation mise à jour.';
            else $errors[] = $stmt->error;
            $stmt->close();
        } else {
            $stmt->close();
            $stmt = $mysqli->prepare('INSERT INTO organisation_societe (entreprise_id, org_dirigeant, duree_vie_annees, repartition_benefice, repartition_perte) VALUES (?,?,?,?,?)');
            $stmt->bind_param('isidd', $entreprise_id, $dirigeant, $duree_vie, $benefice, $perte);
            if ($stmt->execute()) $success[] = 'Organisation ajoutée.';
            else $errors[] = $stmt->error;
            $stmt->close();
        }
    }
}

// Récupérer organisation
$organisation = null;
$result = $mysqli->query("SELECT * FROM organisation_societe WHERE entreprise_id=$entreprise_id LIMIT 1");
if ($result) { $organisation = $result->fetch_assoc(); $result->free(); }

?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Organisation</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
<h2>Organisation de la Société</h2>
<?php if($errors) echo '<div class="alert alert-danger">'.implode('<br>',$errors).'</div>'; ?>
<?php if($success) echo '<div class="alert alert-success">'.implode('<br>',$success).'</div>'; ?>

<form method="post">
<input type="text" name="org_dirigeant" placeholder="Dirigeant" class="form-control mb-2" value="<?php echo htmlspecialchars($organisation['org_dirigeant']??''); ?>">
<input type="number" name="duree_vie" placeholder="Durée de vie (années)" class="form-control mb-2" value="<?php echo htmlspecialchars($organisation['duree_vie_annees']??''); ?>">
<input type="number" step="0.01" name="repartition_benefice" placeholder="Répart. bénéfices %" class="form-control mb-2" value="<?php echo htmlspecialchars($organisation['repartition_benefice']??''); ?>">
<input type="number" step="0.01" name="repartition_perte" placeholder="Répart. pertes %" class="form-control mb-2" value="<?php echo htmlspecialchars($organisation['repartition_perte']??''); ?>">
<button class="btn btn-primary">Mettre à jour</button>
</form>
</div>
</body>
</html>
