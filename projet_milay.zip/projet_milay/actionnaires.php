<?php
session_start();
require_once __DIR__ . '/config.php';

if (empty($_SESSION['entreprise_id'])) {
    header('Location: login.php');
    exit;
}

$entreprise_id = $_SESSION['entreprise_id'];
$errors = [];
$success = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom_actionnaire'] ?? '');
    $capital = floatval($_POST['capital_actionnaire'] ?? 0);
    $part = floatval($_POST['part_actionnaire'] ?? 0);

    if ($nom === '' || $capital <= 0 || $part <= 0) $errors[] = 'Tous les champs sont requis.';
    if (empty($errors)) {
        $stmt = $mysqli->prepare('INSERT INTO actionnaires (entreprise_id, nom, capital_apporte, part_percent) VALUES (?,?,?,?)');
        $stmt->bind_param('isdd', $entreprise_id, $nom, $capital, $part);
        if ($stmt->execute()) $success[] = 'Actionnaire ajouté.';
        else $errors[] = $stmt->error;
        $stmt->close();
    }
}

// Récupérer actionnaires
$actionnaires = [];
$result = $mysqli->query("SELECT * FROM actionnaires WHERE entreprise_id=$entreprise_id");
if ($result) { while($row = $result->fetch_assoc()) $actionnaires[] = $row; $result->free(); }

?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Actionnaires</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
<h2>Actionnaires</h2>
<?php if($errors) echo '<div class="alert alert-danger">'.implode('<br>',$errors).'</div>'; ?>
<?php if($success) echo '<div class="alert alert-success">'.implode('<br>',$success).'</div>'; ?>

<form method="post">
<input type="text" name="nom_actionnaire" placeholder="Nom" class="form-control mb-2" required>
<input type="number" step="0.01" name="capital_actionnaire" placeholder="Capital" class="form-control mb-2" required>
<input type="number" step="0.01" name="part_actionnaire" placeholder="Part %" class="form-control mb-2" required>
<button class="btn btn-primary">Ajouter</button>
</form>

<h4 class="mt-4">Liste des actionnaires</h4>
<ul class="list-group">
<?php foreach($actionnaires as $ac): ?>
<li class="list-group-item"><?php echo htmlspecialchars($ac['nom'].' - Capital: '.$ac['capital_apporte'].' - Part: '.$ac['part_percent'].'%'); ?></li>
<?php endforeach; ?>
</ul>
</div>
</body>
</html>
