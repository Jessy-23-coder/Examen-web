<?php
session_start();
require_once __DIR__ . '/config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';

    if ($email === '' || $mot_de_passe === '') {
        $errors[] = 'Email et mot de passe sont requis.';
    } else {
        $stmt = $mysqli->prepare('SELECT id, nom_entreprise, mot_de_passe_hash FROM entreprises WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($id, $nom_entreprise, $mot_de_passe_hash);
            $stmt->fetch();
            if (password_verify($mot_de_passe, $mot_de_passe_hash)) {
                // Connexion réussie : créer session
                $_SESSION['entreprise_id'] = $id;
                $_SESSION['entreprise_nom'] = $nom_entreprise;
                header('Location: main_entreprise.php');
                exit;
            } else {
                $errors[] = 'Mot de passe incorrect.';
            }
        } else {
            $errors[] = 'Aucun compte trouvé pour cet email.';
        }
        $stmt->close();
    }
}
?>

<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Connexion Entreprise</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
<div class="row justify-content-center">
<div class="col-md-6 col-lg-5">
<div class="card shadow-sm">
<div class="card-body">
<h3 class="card-title mb-3">Connexion Entreprise</h3>

<?php if(!empty($errors)): ?>
<div class="alert alert-danger">
<ul><?php foreach($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<form method="post">
<div class="mb-3">
<label class="form-label">Email</label>
<input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
</div>
<div class="mb-3">
<label class="form-label">Mot de passe</label>
<input type="password" name="mot_de_passe" class="form-control" required>
</div>
<div class="d-flex justify-content-between align-items-center">
<button class="btn btn-primary" type="submit">Se connecter</button>
<a href="register_entreprise.php">Créer un compte</a>
</div>
</form>

</div>
</div>
</div>
</div>
</div>
</body>
</html>
