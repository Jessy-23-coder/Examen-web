<?php
// Rediriger automatiquement vers login.php
header('Location: login.php');
exit;
?>
