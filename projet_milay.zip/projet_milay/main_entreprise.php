<?php
session_start();
require_once __DIR__ . '/config.php';

// Vérifier si l'entreprise est connectée
if (empty($_SESSION['entreprise_id'])) {
    header('Location: login.php');
    exit;
}

$entreprise_id = $_SESSION['entreprise_id'];

// Récupérer le nom de l'entreprise pour affichage
$entreprise_name = '';
$stmt = $mysqli->prepare('SELECT nom_entreprise FROM entreprises WHERE id=? LIMIT 1');
$stmt->bind_param('i', $entreprise_id);
$stmt->execute();
$stmt->bind_result($entreprise_name);
$stmt->fetch();
$stmt->close();

?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Accueil - <?php echo htmlspecialchars($entreprise_name); ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container-fluid">
<a class="navbar-brand" href="main_entreprise.php"><?php echo htmlspecialchars($entreprise_name); ?></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">
<li class="nav-item"><a class="nav-link" href="documents.php">Documents</a></li>
<li class="nav-item"><a class="nav-link" href="actionnaires.php">Actionnaires</a></li>
<li class="nav-item"><a class="nav-link" href="organisation.php">Organisation</a></li>
</ul>
<ul class="navbar-nav">
<li class="nav-item"><a class="nav-link" href="logout.php">Déconnexion</a></li>
</ul>
</div>
</div>
</nav>

<div class="container py-5">
<h1>Bienvenue, <?php echo htmlspecialchars($entreprise_name); ?> !</h1>
<p>Utilisez la navbar pour gérer vos documents, vos actionnaires et l'organisation de votre société.</p>

<div class="row mt-4">
<div class="col-md-4">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Documents</h5>
<p class="card-text">Créer et télécharger vos procès-verbaux, conventions et statuts.</p>
<a href="documents.php" class="btn btn-primary">Gérer les documents</a>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Actionnaires</h5>
<p class="card-text">Ajouter ou modifier vos actionnaires et leurs parts.</p>
<a href="actionnaires.php" class="btn btn-primary">Gérer les actionnaires</a>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card text-center">
<div class="card-body">
<h5 class="card-title">Organisation</h5>
<p class="card-text">Définir le dirigeant, la durée de vie et la répartition des bénéfices/pertes.</p>
<a href="organisation.php" class="btn btn-primary">Gérer l'organisation</a>
</div>
</div>
</div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
