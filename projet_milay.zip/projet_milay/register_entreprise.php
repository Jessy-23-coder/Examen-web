<?php
// register_entreprise.php — formulaire d'inscription simplifié pour les entreprises

session_start();
require_once __DIR__ . '/config.php'; // connexion DB

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}

$errors = [];
$success = false;

// Récupérer tous les types de société pour le dropdown
$types_societe = [];
$result = $mysqli->query('SELECT id, nom_type FROM types_societe ORDER BY nom_type ASC');
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $types_societe[$row['id']] = $row['nom_type'];
    }
    $result->free();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = 'Jeton CSRF invalide.';
    }

    // Récupération des champs
    $nom_entreprise = trim($_POST['nom_entreprise'] ?? '');
    $numero_enregistrement = trim($_POST['numero_enregistrement'] ?? '');
    $type_societe_id = intval($_POST['type_societe_id'] ?? 0);
    $adresse = trim($_POST['adresse'] ?? '');
    $ville = trim($_POST['ville'] ?? '');
    $province = trim($_POST['province'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $telephone = trim($_POST['telephone'] ?? '');
    $nom_contact = trim($_POST['nom_contact'] ?? '');
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    $mot_de_passe_conf = $_POST['mot_de_passe_conf'] ?? '';
    $date_creation = $_POST['date_creation'] ?? null;

    // Validation minimale
    if ($nom_entreprise === '') $errors[] = 'Le nom de l\'entreprise est requis.';
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email invalide.';
    if (strlen($mot_de_passe) < 8) $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
    if ($mot_de_passe !== $mot_de_passe_conf) $errors[] = 'Les mots de passe ne correspondent pas.';
    if ($date_creation) {
        $d = DateTime::createFromFormat('Y-m-d', $date_creation);
        if (!$d || $d->format('Y-m-d') !== $date_creation) $errors[] = 'Date de création invalide (format YYYY-MM-DD).';
    }

    // Vérifier email unique
    if (empty($errors)) {
        $stmt = $mysqli->prepare('SELECT id FROM entreprises WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) $errors[] = 'Un compte avec cet email existe déjà.';
        $stmt->close();
    }

    // Insertion en DB
    if (empty($errors)) {
        $mot_de_passe_hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);
        $sql = 'INSERT INTO entreprises (nom_entreprise, numero_enregistrement, type_societe_id, adresse, ville, province, email, telephone, nom_contact, mot_de_passe_hash, date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param('ssissssssss', $nom_entreprise, $numero_enregistrement, $type_societe_id, $adresse, $ville, $province, $email, $telephone, $nom_contact, $mot_de_passe_hash, $date_creation);
        if ($stmt->execute()) {
            // Créer la session pour l'entreprise
            $_SESSION['entreprise_id'] = $stmt->insert_id; // id nouvellement créé
            $_SESSION['entreprise_nom'] = $nom_entreprise;
            // Redirection vers la page principale
            header('Location: main_entreprise.php');
            exit;
        } else {
            $errors[] = 'Erreur insertion: '.$stmt->error;
        }

        $stmt->close();
    }
}

?>

<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Inscription Entreprise</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
<div class="row justify-content-center">
<div class="col-md-9 col-lg-8">
<div class="card shadow-sm">
<div class="card-body">
<h3 class="card-title mb-3">Créer un compte entreprise</h3>
<?php if(!empty($errors)): ?><div class="alert alert-danger"><ul><?php foreach($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success">Inscription réussie. Vous pouvez maintenant vous connecter.</div><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
<div class="mb-3"><label class="form-label">Nom de l'entreprise *</label><input name="nom_entreprise" value="<?php echo htmlspecialchars($_POST['nom_entreprise']??''); ?>" class="form-control" required></div>
<div class="row">
<div class="col-md-6 mb-3"><label class="form-label">Numéro d'enregistrement</label><input name="numero_enregistrement" value="<?php echo htmlspecialchars($_POST['numero_enregistrement']??''); ?>" class="form-control"></div>
<div class="col-md-6 mb-3"><label class="form-label">Type de société</label><select name="type_societe_id" class="form-select"><option value="">-- Sélectionner --</option><?php foreach($types_societe as $id=>$nom): ?><option value="<?php echo $id; ?>" <?php if(isset($_POST['type_societe_id']) && $_POST['type_societe_id']==$id) echo 'selected'; ?>><?php echo htmlspecialchars($nom); ?></option><?php endforeach; ?></select></div>
</div>
<div class="mb-3"><label class="form-label">Adresse</label><input name="adresse" value="<?php echo htmlspecialchars($_POST['adresse']??''); ?>" class="form-control"></div>
<div class="row">
<div class="col-md-6 mb-3"><label class="form-label">Ville</label><input name="ville" value="<?php echo htmlspecialchars($_POST['ville']??''); ?>" class="form-control"></div>
<div class="col-md-6 mb-3"><label class="form-label">Province / Région</label><input name="province" value="<?php echo htmlspecialchars($_POST['province']??''); ?>" class="form-control"></div>
</div>
<div class="row">
<div class="col-md-6 mb-3"><label class="form-label">Email *</label><input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email']??''); ?>" class="form-control" required></div>
<div class="col-md-6 mb-3"><label class="form-label">Téléphone</label><input name="telephone" value="<?php echo htmlspecialchars($_POST['telephone']??''); ?>" class="form-control"></div>
</div>
<div class="mb-3"><label class="form-label">Contact principal</label><input name="nom_contact" value="<?php echo htmlspecialchars($_POST['nom_contact']??''); ?>" class="form-control"></div>
<div class="row">
<div class="col-md-6 mb-3"><label class="form-label">Mot de passe *</label><input type="password" name="mot_de_passe" class="form-control" required></div>
<div class="col-md-6 mb-3"><label class="form-label">Confirmer mot de passe *</label><input type="password" name="mot_de_passe_conf" class="form-control" required></div>
</div>
<div class="mb-3"><label class="form-label">Date de création (YYYY-MM-DD)</label><input type="date" name="date_creation" value="<?php echo htmlspecialchars($_POST['date_creation']??''); ?>" class="form-control"></div>
<div class="d-flex justify-content-between align-items-center"><small class="text-muted">* champs obligatoires</small><button class="btn btn-primary" type="submit">Créer le compte</button></div>
</form>
</div></div></div></div></div>
</body>
</html>
