<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/fpdf.php';

if (empty($_SESSION['entreprise_id'])) {
    header('Location: login.php');
    exit;
}

$entreprise_id = $_SESSION['entreprise_id'];
$errors = [];
$success = [];

// --- AJOUT / MODIFICATION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_id = intval($_POST['doc_id'] ?? 0);
    $type_document = $_POST['type_document'] ?? '';
    $titre = trim($_POST['titre_document'] ?? '');
    $date_document = $_POST['date_document'] ?? null;
    $contenu = trim($_POST['contenu_document'] ?? '');

    if ($type_document === '' || $titre === '') $errors[] = 'Type et titre requis.';

    if (empty($errors)) {
        if ($doc_id > 0) {
            // Modifier document existant
            $stmt = $mysqli->prepare('UPDATE documents_societe SET type_document=?, titre=?, date_document=?, contenu=?, chemin_pdf=NULL WHERE id=? AND entreprise_id=?');
            $stmt->bind_param('ssssii', $type_document, $titre, $date_document, $contenu, $doc_id, $entreprise_id);
            if ($stmt->execute()) $success[] = 'Document modifié. Le PDF sera régénéré à la prochaine récupération.';
            else $errors[] = $stmt->error;
            $stmt->close();
        } else {
            // Ajouter nouveau document
            $stmt = $mysqli->prepare('INSERT INTO documents_societe (entreprise_id, type_document, titre, date_document, contenu) VALUES (?,?,?,?,?)');
            $stmt->bind_param('issss', $entreprise_id, $type_document, $titre, $date_document, $contenu);
            if ($stmt->execute()) $success[] = 'Document ajouté.';
            else $errors[] = $stmt->error;
            $stmt->close();
        }
    }
}

// --- SUPPRESSION ---
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    $stmt = $mysqli->prepare('SELECT chemin_pdf FROM documents_societe WHERE id=? AND entreprise_id=?');
    $stmt->bind_param('ii', $delete_id, $entreprise_id);
    $stmt->execute();
    $stmt->bind_result($chemin_pdf);
    if ($stmt->fetch()) {
        if ($chemin_pdf && file_exists($chemin_pdf)) unlink($chemin_pdf);
        $stmt->close();
        $stmt2 = $mysqli->prepare('DELETE FROM documents_societe WHERE id=? AND entreprise_id=?');
        $stmt2->bind_param('ii', $delete_id, $entreprise_id);
        $stmt2->execute();
        $stmt2->close();
        $success[] = 'Document supprimé.';
    } else $errors[] = 'Document non trouvé.';
}

// --- EDITION ---
$edit_doc = null;
if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $stmt = $mysqli->prepare('SELECT * FROM documents_societe WHERE id=? AND entreprise_id=?');
    $stmt->bind_param('ii', $edit_id, $entreprise_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $edit_doc = $res->fetch_assoc();
    $stmt->close();
}

// --- Récupérer tous les documents ---
$documents = [];
$result = $mysqli->query("SELECT * FROM documents_societe WHERE entreprise_id=$entreprise_id ORDER BY date_document DESC");
if ($result) { while($row = $result->fetch_assoc()) $documents[] = $row; $result->free(); }

?>

<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Documents</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">

<h2>Documents de l'entreprise</h2>

<?php if($errors) echo '<div class="alert alert-danger">'.implode('<br>',$errors).'</div>'; ?>
<?php if($success) echo '<div class="alert alert-success">'.implode('<br>',$success).'</div>'; ?>

<!-- Formulaire Ajout / Modification -->
<form method="post" class="mb-4">
<input type="hidden" name="doc_id" value="<?php echo $edit_doc['id'] ?? 0; ?>">
<select name="type_document" class="form-select mb-2" required>
<option value="">-- Type de document --</option>
<option value="Procès-verbal" <?php if(isset($edit_doc) && $edit_doc['type_document']=='Procès-verbal') echo 'selected'; ?>>Procès-verbal</option>
<option value="Convention" <?php if(isset($edit_doc) && $edit_doc['type_document']=='Convention') echo 'selected'; ?>>Convention</option>
<option value="Statuts" <?php if(isset($edit_doc) && $edit_doc['type_document']=='Statuts') echo 'selected'; ?>>Statuts</option>
</select>
<input type="text" name="titre_document" class="form-control mb-2" placeholder="Titre du document" value="<?php echo $edit_doc['titre'] ?? ''; ?>" required>
<input type="date" name="date_document" class="form-control mb-2" value="<?php echo $edit_doc['date_document'] ?? ''; ?>">
<textarea name="contenu_document" class="form-control mb-2" placeholder="Contenu du document"><?php echo $edit_doc['contenu'] ?? ''; ?></textarea>
<button class="btn btn-primary"><?php echo $edit_doc ? 'Modifier' : 'Ajouter'; ?></button>
<?php if($edit_doc): ?><a href="documents.php" class="btn btn-secondary">Annuler</a><?php endif; ?>
</form>

<h4>Liste des documents</h4>
<ul class="list-group">
<?php foreach($documents as $doc): ?>
<li class="list-group-item d-flex justify-content-between align-items-center">
<div>
<?php echo htmlspecialchars($doc['type_document'].' - '.$doc['titre'].' ('.$doc['date_document'].')'); ?>
</div>
<div>
<a href="telecharger_pdf.php?id=<?php echo $doc['id']; ?>" class="btn btn-sm btn-success" target="_blank">PDF</a>
<a href="documents.php?edit=<?php echo $doc['id']; ?>" class="btn btn-sm btn-warning">Modifier</a>
<a href="documents.php?delete=<?php echo $doc['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Supprimer ce document ?');">Supprimer</a>
</div>
</li>
<?php endforeach; ?>
</ul>

</div>
</body>
</html>
