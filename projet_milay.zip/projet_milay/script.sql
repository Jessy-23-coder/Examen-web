<?php

CREATE DATABASE IF NOT EXISTS gestion_societe DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE gestion_societe;

-- Table pour types de société (SARL, SA, SAS...)
CREATE TABLE IF NOT EXISTS types_societe (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom_type VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table principale des entreprises
CREATE TABLE IF NOT EXISTS entreprises (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom_entreprise VARCHAR(255) NOT NULL,
  numero_enregistrement VARCHAR(100) DEFAULT NULL,
  type_societe_id INT UNSIGNED DEFAULT NULL,
  adresse VARCHAR(255) DEFAULT NULL,
  ville VARCHAR(100) DEFAULT NULL,
  province VARCHAR(100) DEFAULT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  telephone VARCHAR(50) DEFAULT NULL,
  nom_contact VARCHAR(150) DEFAULT NULL,
  mot_de_passe_hash VARCHAR(255) NOT NULL,
  date_creation DATE DEFAULT NULL,
  date_creation_compte TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (type_societe_id) REFERENCES types_societe(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE documents_societe (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entreprise_id INT UNSIGNED NOT NULL,
    type_document ENUM('Procès-verbal','Convention','Statuts') NOT NULL,
    titre VARCHAR(255) NOT NULL,
    date_document DATE DEFAULT NULL,
    contenu TEXT DEFAULT NULL,
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE documents_societe
ADD COLUMN chemin_pdf VARCHAR(255) DEFAULT NULL AFTER contenu;


CREATE TABLE actionnaires (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entreprise_id INT UNSIGNED NOT NULL,
    nom VARCHAR(255) NOT NULL,
    capital_apporte DECIMAL(15,2) NOT NULL,
    part_percent DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



CREATE TABLE organisation_societe (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entreprise_id INT UNSIGNED NOT NULL,
    org_dirigeant VARCHAR(255) DEFAULT NULL,
    duree_vie_annees INT DEFAULT NULL,
    repartition_benefice DECIMAL(5,2) DEFAULT NULL,
    repartition_perte DECIMAL(5,2) DEFAULT NULL,
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO types_societe (nom_type) VALUES
('SARL'),
('SA'),
('SAS'),
('SCI'),
('EURL'),
('SNC'),
('Coopérative');


INSERT INTO documents_societe (entreprise_id, type_document, titre, date_document, contenu)
VALUES
(1, 'Procès-verbal', 'Assemblée Générale 2025', '2025-09-24', 'Décisions prises lors de l’assemblée générale annuelle.'),
(1, 'Convention', 'Convention de Partenariat', '2025-08-15', 'Convention signée avec la société XYZ pour un partenariat stratégique.'),
(1, 'Statuts', 'Mise à jour des statuts', '2025-01-10', 'Modification des statuts de la société pour inclure de nouvelles clauses.');


INSERT INTO actionnaires (entreprise_id, nom, capital_apporte, part_percent)
VALUES
(1, 'Jean Rakoto', 50000.00, 50.00),
(1, 'Lala Rasoanaivo', 30000.00, 30.00),
(1, 'Fara Ravaoarisoa', 20000.00, 20.00);



INSERT INTO organisation_societe (entreprise_id, org_dirigeant, duree_vie_annees, repartition_benefice, repartition_perte)
VALUES
(1, 'Andry R.', 20, 60.00, 40.00);

