<?php
session_start();
require_once __DIR__ . '/config.php'; // connexion à la base
require_once __DIR__ . '/lib/fpdf.php';

if (empty($_SESSION['entreprise_id'])) {
    header('Location: login.php');
    exit;
}

$entreprise_id = $_SESSION['entreprise_id'];
$doc_id = intval($_GET['id'] ?? 0);

if ($doc_id <= 0) {
    die('Document invalide.');
}

// Récupérer le document depuis la base
$stmt = $mysqli->prepare('SELECT type_document, titre, date_document, contenu, chemin_pdf 
                          FROM documents_societe 
                          WHERE id=? AND entreprise_id=? LIMIT 1');
$stmt->bind_param('ii', $doc_id, $entreprise_id);
$stmt->execute();
$stmt->bind_result($type_document, $titre, $date_document, $contenu, $chemin_pdf);
if (!$stmt->fetch()) {
    die('Document non trouvé.');
}
$stmt->close();

// Nom du fichier PDF
$pdf_filename = 'document_'.$doc_id.'.pdf';

// Si PDF existe déjà sur le serveur, on le sert
if (!empty($chemin_pdf) && file_exists($chemin_pdf)) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="'.$pdf_filename.'"');
    readfile($chemin_pdf);
    exit;
}

// Sinon, générer le PDF avec FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16); // titre en gras
$pdf->Cell(0,10, utf8_decode($type_document . ' : ' . $titre), 0, 1, 'C');
$pdf->Ln(5);
$pdf->SetFont('Arial','',12); // contenu normal
$pdf->MultiCell(0,6, utf8_decode("Date : $date_document\n\n$contenu"));

// Créer le dossier uploads/documents si nécessaire
$pdf_dir = __DIR__ . '/uploads/documents';
if (!is_dir($pdf_dir)) mkdir($pdf_dir, 0755, true);

// Chemin complet pour sauvegarder le PDF
$pdf_file = $pdf_dir . '/' . $pdf_filename;
$pdf->Output('F', $pdf_file);

// Mettre à jour le chemin PDF en base de données
$stmt2 = $mysqli->prepare('UPDATE documents_societe SET chemin_pdf=? WHERE id=?');
$stmt2->bind_param('si', $pdf_file, $doc_id);
$stmt2->execute();
$stmt2->close();

// Afficher le PDF dans le navigateur (inline)
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="'.$pdf_filename.'"');
readfile($pdf_file);
exit;
?>
